## FINAL PROJECT
#### Execute in Release X64 mode
---
#### Gameplay:
-  Game is about TIC TAC TOE
-  Player wins by X O placments
-  Mouse and left click to pan and SPACE shoot the X and O
-  Tab to show the constraints given for X in 0,0 location

---
#### Controls:
-  MOUSE - Pan the Game
-  SPACE - Fire Weapon
-  TAB - Push the constraint(Did for left top corner object X)

